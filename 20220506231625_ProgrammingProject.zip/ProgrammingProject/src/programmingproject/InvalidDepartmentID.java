/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject;

/**
 *
 * @author trevortam
 */
public class InvalidDepartmentID extends Exception{
    public InvalidDepartmentID() {
        super("ERROR: INVALID DEPARTMENT ID");
    }
    public InvalidDepartmentID(int i) {
        super("ERROR: INVALID DEPARTMENT ID: " + i);
    }
}
