/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author trevortam
 */
public class ProgrammingProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
//        teachers.add(new Teacher("Master", "Bachelor", "Trevor", "Tam", "trevortam99@gmail.com", "Normal", 18, 19));
        
//        System.out.print(teachers);
        
        PartTime demo = new PartTime(100,"Teacher", "Bachelor", "Spyro", "Goumas", "goumygoumygou@gmail.com", "Normal", 18, 1928);
        demo.computePayRoll();
        
//        System.out.println(demo);
//        
//        System.out.println("---------------------------");
        
        FullTime demo2 = new FullTime(200, "Teacher", "PhD", "Samuel", "Jackson", "idk@gmail.com", "Normal", 60, 2938);
        
        Teacher[] teachers = new Teacher[2];
        teachers[0] = demo;
        teachers[1] = demo2;
        
        for(int i = 0; i < teachers.length; i++) {
            String outputText = teachers[i].getCategory() + ", " + teachers[i].getDegree() + ", " + teachers[i].getFname() + ", "
                    + teachers[i].getLname() + ", " + teachers[i].getEmail() + ", " + teachers[i].getGender() + ", " + teachers[i].getAge() 
                    + ", " + teachers[i].getPersonID() + ", " + teachers[i].computePayRoll();
            
            try {
                saveTofile("teacherslist.txt", outputText, true);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
//        System.out.println(demo2);
//        
//        System.out.println("---------------------------");
        
        Payroll demo3 = new Staff("I don't know", 30, "Muhammad", "Ali", "muhammadali@gmail.com", "Normal", 40, 1934);
        System.out.println(demo3);
        
        try {
            demo.setPersonID(personID);
        } catch (Exception e) {
            System.out.println("" + e.getMessage());
        }
            
    }

    private static void saveTofile(String fileName, String text, boolean b) throws IOException {
        File file = new File(fileName);
        
        FileWriter fw = new FileWriter(file, b);
        
        PrintWriter pw = new PrintWriter(fw);
        
        pw.println(text);
        
        pw.close();
    }
    
}
