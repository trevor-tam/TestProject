/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject;

/**
 *
 * @author trevortam
 */
public class Teacher extends Person implements Payroll{
    private String specialty;
    private String degree;

    public Teacher(String specialty, String degree, String fname, String lname, String email, String gender, int age, int personID) {
        super(fname, lname, email, gender, age, personID);
        this.specialty = specialty;
        this.degree = degree;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }
    
    public boolean equals (Teacher teacher) {
        if(!specialty.equals(teacher.specialty)) 
            return false;
        if(!degree.equals(teacher.degree))
            return false;
        return true;
    }
    @Override
    public String toString() {
        String str = "";
        
        str += String.format("Specialty: %s\n", specialty);
        str += String.format("Degree: %s\n", degree);
        str += String.format("First Name: %s\n", getFname());
        str += String.format("Last Name: %s\n", getLname());
        str += String.format("Email: %s\n", getEmail());
        str += String.format("Gender: %s\n", getGender());
        str += String.format("Age: %d\n", getAge());
        str += String.format("ID: %d\n", getPersonID());
        str += String.format("Salary: %d\n", computePayRoll());
        
        return str;
    }
    @Override
    public String getCategory() {
        return "";
    }

    @Override
    public double computePayRoll() {
       return 1;
    }

}
