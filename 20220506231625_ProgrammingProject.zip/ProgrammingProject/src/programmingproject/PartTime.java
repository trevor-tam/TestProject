/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject;

/**
 *
 * @author trevortam
 */
public class PartTime extends Teacher implements Payroll{
    private int hoursWorked;

    public PartTime(int hoursWorked, String specialty, String degree, String fname, String lname, String email, String gender, int age, int personID) {
        super(specialty, degree, fname, lname, email, gender, age, personID);
        this.hoursWorked = hoursWorked;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }
    @Override
    public double computePayRoll() {
        int degreeRate = 0;
        if(getDegree() == "PhD")
            degreeRate = 112;
        if(getDegree() == "Master")
            degreeRate = 82;
        if(getDegree() == "Bachelor")
            degreeRate = 42;
        
        double salary = (hoursWorked * degreeRate * 2) * 0.75;
        
        return salary;
    } 
    @Override
    public String toString() {
        String str = "";
        
        str += String.format("Hours Worked: %d\n", hoursWorked);
        str += String.format("Specialty: %s\n", getSpecialty());
        str += String.format("Degree: %s\n", getDegree());
        str += String.format("First Name: %s\n", getFname());
        str += String.format("Last Name: %s\n", getLname());
        str += String.format("Email: %s\n", getEmail());
        str += String.format("Gender: %s\n", getGender());
        str += String.format("Age: %d\n", getAge());
        str += String.format("ID: %d\n", getPersonID());
        str += String.format("Salary: %.2f\n", computePayRoll());
        
        return str;
    }
}
