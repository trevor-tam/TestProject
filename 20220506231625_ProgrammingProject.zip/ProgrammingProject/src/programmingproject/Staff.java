/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject;

/**
 *
 * @author trevortam
 */
public class Staff extends Person implements Payroll{
    private String duty;
    private int workload;

    public Staff(String duty, int workload, String fname, String lname, String email, String gender, int age, int personID) {
        super(fname, lname, email, gender, age, personID);
        this.duty = duty;
        this.workload = workload;
    }

    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty;
    }

    public int getWorkload() {
        return workload;
    }

    public void setWorkload(int workload) {
        if(workload <= 40)
        this.workload = workload;
    }
    
    public boolean equals (Staff staff) {
        if(!this.duty.equals(staff.duty))
            return false;
        if(workload != staff.workload)
            return false;
        return true;
    }
    @Override
    public String toString() {
        String str = "";
        
        str += String.format("Duty: %s\n", duty);
        str += String.format("Workload: %d\n", workload);
        str += String.format("First Name: %s\n", getFname());
        str += String.format("Last Name: %s\n", getLname());
        str += String.format("Email: %s\n", getEmail());
        str += String.format("Gender: %s\n", getGender());
        str += String.format("Age: %d\n", getAge());
        str += String.format("ID: %d\n", getPersonID());
        str += String.format("Salary: %.2f\n", computePayRoll());
        
        return str;
    }

    @Override
    public String getCategory() {
        return "";
    }

    @Override
    public double computePayRoll() {
       double salary = (workload * 32 * 2) * 0.75;
       
       return salary;
    }
}
