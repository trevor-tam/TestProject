/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author trevortam
 */
public class Department{
    private int departmentID;
    ArrayList<Teacher> teachers = new ArrayList<Teacher>();
    ArrayList<Staff> staffs = new ArrayList<Staff>();
    Teacher dean;
    
  
    

    public Department(int departmentID, Teacher dean) {
        this.departmentID = departmentID;
        
    }

    public int getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(int departmentID) throws Exception{
        if(this.departmentID == departmentID) {
        } else 
            throw new InvalidDepartmentID(departmentID);
    }

    public ArrayList<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(ArrayList<Teacher> teachers) {
        this.teachers = teachers;
    }

    public ArrayList<Staff> getStaffs() {
        return staffs;
    }

    public void setStaffs(ArrayList<Staff> staffs) {
        this.staffs = staffs;
    }
    
    public Teacher  getDean(Teacher dean) {
        return dean;
    }
    public void setDean(Teacher dean) {
        this.dean = dean;
    }
    public String toString() {
        String str = "";
        
        str += String.format("Department ID: %d\n", departmentID);
        str += String.format("Teacher: \n %s", getTeachers().toString());
        str += String.format("Staff: \n %s\n", getStaffs().toString());
        
        return str;
    }
}

